package com.java;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int size = sc.nextInt();
		int[] arr = new int[size];
		for (int i=0; i<size ; i++) {
			arr[i] = sc.nextInt();
		}
		 moveZeroes(arr);

	}
	public static void moveZeroes(int[] nums) {
	    int i = 0; // Pointer to track the position of the next nonzero element
	    
	    // Traverse the array
	    for (int j = 0; j < nums.length; j++) {
	        // If the current element is nonzero
	        if (nums[j] != 0) {
	            // Swap the current element with the next nonzero element
	            int temp = nums[i];
	            nums[i] = nums[j];
	            nums[j] = temp;
	            
	            // Increment the pointer for the next nonzero element
	            i++;
	        }
	    }
	}


}
