package com.question2.main;

public class Main {

	public static void main(String[] args) {
		int[] nums = {3, 2, 2, 3};
        int val = 3;
        
        int k = removeElement(nums, val);
        
        System.out.println("Updated array:");
        for (int i = 0; i < k; i++) {
            System.out.print(nums[i] + " ");
        }
        System.out.println();
        
        System.out.println("Number of elements not equal to " + val + ": " + k);

	}
	
	public static int removeElement(int[] nums, int val) {
        int k = 0; // Count of elements not equal to val
        
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != val) {
                nums[k] = nums[i]; // Move the element to the beginning of the array
                k++; // Increment count of elements not equal to val
            }
        }
        
        return k; // Return the count of elements not equal to val
    }

}
