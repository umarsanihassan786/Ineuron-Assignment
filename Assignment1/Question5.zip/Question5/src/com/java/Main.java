package com.java;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int y = sc.nextInt();
		int size = sc.nextInt();
		int[] arr1 = new int[size];
		int[] arr2 = new int[size];
		for (int i=0; i<size ; i++) {
			arr1[i] = sc.nextInt();
			arr2[i] = sc.nextInt();
		}
		int ans = (Integer) null;
		
		merge(arr1, x, arr2, y);

	}
	public static void merge(int[] nums1, int m, int[] nums2, int n) {
	    int i = m - 1; // Pointer for nums1
	    int j = n - 1; // Pointer for nums2
	    int k = m + n - 1; // Pointer for the merged array

	    while (i >= 0 && j >= 0) {
	        if (nums1[i] >= nums2[j]) {
	            nums1[k] = nums1[i];
	            i--;
	        } else {
	            nums1[k] = nums2[j];
	            j--;
	        }
	        k--;
	    }

	    // If there are remaining elements in nums2, copy them to the merged array
	    while (j >= 0) {
	        nums1[k] = nums2[j];
	        j--;
	        k--;
	    }
	}


}
