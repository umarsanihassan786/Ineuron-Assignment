package com.java;

import java.util.HashSet;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int size = sc.nextInt();
		int[] arr = new int[size];
		for (int i=0; i<size ; i++) {
			arr[i] = sc.nextInt();
		}
		boolean ans = containsDuplicate(arr);

	}
	public static boolean containsDuplicate(int[] nums) {
	    HashSet<Integer> set = new HashSet<>();
	    
	    for (int num : nums) {
	        if (set.contains(num)) {
	            return true;
	        }
	        set.add(num);
	    }
	    
	    return false;
	}
}
