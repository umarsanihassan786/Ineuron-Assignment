package com.java;

import java.util.HashSet;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int size = sc.nextInt();
		int[] arr = new int[size];
		for (int i=0; i<size ; i++) {
			arr[i] = sc.nextInt();
		}
		int[] ans = findErrorNums(arr);

	}

	public static int[] findErrorNums(int[] nums) {
	    int n = nums.length;
	    int[] result = new int[2];

	    HashSet<Integer> set = new HashSet<>();
	    int sum = (n * (n + 1)) / 2; // The expected sum of the numbers from 1 to n

	    for (int num : nums) {
	        if (set.contains(num)) {
	            result[0] = num; // Found the number that occurs twice
	        } else {
	            set.add(num);
	            sum -= num; // Calculate the sum of the remaining numbers
	        }
	    }

	    result[1] = sum; // The missing number is the remaining sum

	    return result;
	}

}
