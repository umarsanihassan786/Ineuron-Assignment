package com.question1.main;

import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int size = sc.nextInt();
		int[] arr = new int[size];
		for (int i=0; i<size ; i++) {
			arr[i] = sc.nextInt();
		}
		int[] ans = null;
		ans = twoSum(arr, x);
		

	}

	    public static int[] twoSum(int[] nums, int target) {
	        // Create a HashMap to store values and their indices
	        HashMap<Integer, Integer> numIndices = new HashMap<>();
	        
	        for (int i = 0; i < nums.length; i++) {
	            int complement = target - nums[i];
	            
	            if (numIndices.containsKey(complement)) {
	                // If the complement is found in the HashMap, return the indices
	                return new int[] { numIndices.get(complement), i };
	            }
	            
	            // Store the current value and its index in the HashMap
	            numIndices.put(nums[i], i);
	        }
	        
	        // No solution found, return an empty array
	        return new int[0];
	    }


}
